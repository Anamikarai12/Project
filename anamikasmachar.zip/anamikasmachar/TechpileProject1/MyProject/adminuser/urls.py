from django.urls import path,include
from . import views

urlpatterns=[
    path('',views.add1),
    path('addcategory/',views.add1),
    path('addproduct/',views.add2),
    path('management/',views.manag),
]