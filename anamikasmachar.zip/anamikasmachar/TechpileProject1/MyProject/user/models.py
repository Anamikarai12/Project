from django.db import models

# Create your models here.
class contact(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=120)
    mobile=models.CharField(max_length=20)
    message=models.CharField(max_length=600)


class category(models.Model):
    cname=models.CharField(max_length=40)
    cpic=models.ImageField(upload_to='static/category/',default="")
    cdate=models.DateField()

    def __str__(self):
        return self.cname

class news(models.Model):
    city=models.CharField(max_length=200)
    headlines=models.CharField(max_length=400)
    subject=models.CharField(max_length=800)
    newsdes=models.TextField(max_length=8000)
    newspic=models.ImageField(upload_to='static/news/',default="")
    ndate=models.DateField()
    ncategory=models.ForeignKey(category,on_delete=models.CASCADE)

class videonews(models.Model):
    vurls=models.CharField(max_length=200)
    vheadlines=models.CharField(max_length=500)
    vpara=models.TextField(max_length=1000,default="")
    vpic=models.ImageField(upload_to='static/videopic/',default="")
    vdate=models.DateField()

class slidernews(models.Model):
    sheadlines=models.CharField(max_length=500)
    spic=models.ImageField(upload_to='static/sliderpic/',default="")
    sdate=models.DateField()

class notification(models.Model):
    notheadlines=models.CharField(max_length=200)
    notdate=models.DateField()

class cricket(models.Model):
    cricketpic=models.ImageField(upload_to='static/cricketpic/',default="")
    cridate=models.DateField()

class city(models.Model):
    cityname=models.CharField(max_length=200)
    cdate=models.DateField()