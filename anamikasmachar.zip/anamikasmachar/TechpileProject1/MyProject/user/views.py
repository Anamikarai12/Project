from django.shortcuts import render
from django.http import HttpResponse
from .models import *

# Create your views here.
def home(request):
    cdata=category.objects.all().order_by('-id')[0:6]
    ndata=news.objects.all().order_by('-id')[0:3]
    citydata=city.objects.all().order_by('-id')[0:]
    cityd=news.objects.all().order_by('-id')[0:8]
    cridata=news.objects.all().order_by('-id')[0:1]
    diddata=news.objects.all().order_by('-id')[3:9]
    didata=news.objects.all().order_by('-id')[3:5]
    sdata=slidernews.objects.all().order_by('-id')[0:3]
    notedata=notification.objects.all().order_by('-id')[0:8]
    dict={"data":cdata,"news":ndata,"sdata":sdata,"cricket":cridata,"city":citydata,"citynews":cityd,"didata":didata,"diddata":diddata,'note':notedata}
    return render(request,'user/index.html',dict)

def about(request):
    return render(request,'user/about.html')

def viewnew(request):

    return render(request,'user/viewnew.html')
def login(request):

    return render(request,'user/loin.html')

def video(request):
    vdata=videonews.objects.all().order_by('-id')[0:]
    return render(request,'user/video.html',{"vdata":vdata})

def cont(request):
    # mydict={"A":"Rohit","B":"GPA","C":"9889702929"}
    status=False
    if request.method=='POST':
        Name=request.POST.get("name")
        Mobile=request.POST.get("mobile")
        Email=request.POST.get("email")
        Message=request.POST.get("msg")
        #contact(name=Name,mobile=Mobile,email=Email,message=Message).save()
        x=contact(name=Name,mobile=Mobile,email=Email,message=Message)
        x.save()
        status=True

    return render(request,'user/contactus.html',{'s':status})


def viewmore(request):
    a=request.GET.get("smg")
    ndata=news.objects.filter(id=a)
    return render(request,'user/viewmore.html',{"data":ndata})

def vnews(request):
    cdata=category.objects.all().order_by('-id')

    a=request.GET.get('abc')
    ndata = ""
    if a is None:
        ndata=news.objects.all()
    else:
        ndata=news.objects.filter(ncategory=a)

    citydata = city.objects.all().order_by('-id')[0:]


    return render(request,'user/news.html',{"c":cdata,"n":ndata,"d":citydata})
