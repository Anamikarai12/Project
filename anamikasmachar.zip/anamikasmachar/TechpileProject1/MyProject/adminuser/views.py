from django.shortcuts import render

# Create your views here.
def add1(req):
    return render(req,'admin/addcategory.html')

def add2(req):
    return render(req,'admin/addproduct.html')

def manag(req):
    return render(req,'admin/management.html')