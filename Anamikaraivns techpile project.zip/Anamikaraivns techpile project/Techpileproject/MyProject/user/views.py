from django.shortcuts import render
from .models import *
from django.http import HttpResponse
import datetime
from django.db import connection

# Create your views here.
def home(request):
    cdata=category.objects.all().order_by('-id')[0:6]
    pdata=products.objects.all().order_by('id')[0:4]
    noofitemincart=addtocart.objects.all().count()

    return render(request,'user/index.html',{"data":cdata,"product":pdata,"noofitemincart":noofitemincart})
def about(request):
    noofitemincart = addtocart.objects.all().count()
    return render(request,'user/about.html',{"noofitemincart":noofitemincart})
def contactus(request):
    noofitemincart = addtocart.objects.all().count()
    status=False
    if request.method=='POST':
        Name=request.POST.get("name","")
        Mobile=request.POST.get("mobile","")
        Email=request.POST.get("email","")
        Message=request.POST.get("msg","")
        res=contact(name=Name,contact=Mobile,email=Email,message=Message)
        res.save()
        status=True
        #return HttpResponse("<script>alert('Thanks for enquery');window.location.href='/user/contactus/'</script>")

    return render(request,'user/contactus.html',{'s':status,'noofitemincart':noofitemincart})
def services(request):
    noofitemincart = addtocart.objects.all().count()
    return render(request,'user/services.html',{"noofitemincart":noofitemincart})
def myorders(request):
    noofitemincart = addtocart.objects.all().count()
    userid=request.session.get('userid')
    oid=request.GET.get('oid')
    if userid:
        cursor=connection.cursor()
        cursor.execute("select o.*,p.* from user_order o,user_products p where o.pid=p.id and o.userid='"+str(userid)+"'")
        orderdata=cursor.fetchall()
        if oid:
            result=order.objects.filter(id=oid,userid=userid)
            result.delete()
            return HttpResponse("<script>alert('Your order has been cancled..');window.location.href='/user/myorders'</script>")
    return render(request,'user/myorders.html',{"pendingorder":orderdata,"noofitemincart":noofitemincart})
def myprofile(request):
    user=request.session.get('userid')
    pdata=profile.objects.filter(email=user)
    if user:
        if request.method == 'POST':
            name = request.POST.get("name", "")
            mobile = request.POST.get("mobile", "")
            password = request.POST.get("passwd", "")
            picname = request.FILES['fu']
            address = request.POST.get("address", "")
            profile(email=user,name=name,passwd=password,mobile=mobile,ppic=picname,address=address).save()
            return HttpResponse("<script>alert('Your profile updated successfully');window.location.href='/user/myprofile'</script>")
    noofitemincart = addtocart.objects.all().count()

    return render(request,'user/myprofile.html',{"profile":pdata,"noofitemincart":noofitemincart})
def signup(request):
    noofitemincart = addtocart.objects.all().count()
    if request.method=='POST':
        name=request.POST.get("name","")
        mobile=request.POST.get("mobile","")
        email=request.POST.get("email","")
        password=request.POST.get("passwd","")
        picname=request.FILES['fu']
        address=request.POST.get("address","")
        d=profile.objects.filter(email=email)
        if d.count()>0:
            return HttpResponse("<script>alert('You are already registered..');window.location.href='/user/signup'</script>")
        else:
            profile(name=name,mobile=mobile,email=email,passwd=password,address=address,ppic=picname).save()
            return HttpResponse("<script>alert('Registered successfully..');window.location.href='/user/signup'</script>")

        #return HttpResponse("<script>alert('Sing up successfully....');window.location.href='/user/signup'</script>")
    return render(request,'user/signup.html',{"noofitemincart":noofitemincart})

def prod(request):
    noofitemincart = addtocart.objects.all().count()
    cdata=category.objects.all().order_by('-id')
    x=request.GET.get('abc')
    pdata=""
    if x is not None:
        pdata=products.objects.filter(category=x)
    else:
        pdata = products.objects.all().order_by('-id')

    return render(request,'user/product.html',{"cat":cdata,"product":pdata,"noofitemincart":noofitemincart})
def signin(request):
    noofitemincart = addtocart.objects.all().count()
    if request.method=='POST':
        uname=request.POST.get("email","")
        pwd=request.POST.get("passwd","")
        checkuser=profile.objects.filter(email=uname,passwd=pwd)
        #print(checkuser)
        if(checkuser):
            request.session['userid']=uname
            return HttpResponse("<script>alert('your registration successfull');window.location.href='/user/signin/';</script>")
        else:
            return HttpResponse("<script>alert('id password invalid');window.location.href='/user/signin';</script>")
    return render(request,'user/signin.html',{"noofitemincart":noofitemincart})

def viewdetails(request):
    noofitemincart = addtocart.objects.all().count()
    a=request.GET.get('msg')
    data=products.objects.filter(id=a)
    return render(request,'user/viewdetails.html',{"d":data,"noofitemincart":noofitemincart})

def process(request):
    userid=request.session.get('userid')
    pid=request.GET.get('pid')
    btn=request.GET.get('bn')
    print(userid,pid,btn)
    if userid is not None:
        if btn=='cart':
            checkcartitem=addtocart.objects.filter(pid=pid,userid=userid)
            if checkcartitem.count()==0:
                addtocart(pid=pid,userid=userid,status=True,cdate=datetime.datetime.now()).save()
                return HttpResponse("<script>alert('Your items is successfully added in cart...');window.location.href='/user/home/'</script>")

            else:
                return HttpResponse("<script>alert('This items is already added in cart...');window.location.href='/user/home/'</script>")
        elif btn=='order':
            order(pid=pid,userid=userid,remarks="pending",status=True,odate=datetime.datetime.now()).save()
            return HttpResponse("<script>alert('Your order have confirmed...');window.location.href='/user/myorders/'</script>")
        #return render(request,'user/process.html',{"alreadylogin":True})
        elif btn=='orderfromcart':
            res=addtocart.objects.filter(pid=pid,userid=userid)
            res.delete()
            order(pid=pid,userid=userid,remarks="Pending",status=True,odate=datetime.datetime.now()).save()
            return HttpResponse("<script>alert('Your order have confirmed...');window.location.href='/user/myorders/'</script>")
        return render(request, 'user/process.html', {"alreadylogin": True})
    else:
        return HttpResponse("<script>window.location.href='/user/signin/'</script>")
        #return render(request,'user/signin.html')
    #return render(request,'user/process.html')

def logout(request):
    del request.session['userid']
    #return render(request,"user/logout.html")
    return HttpResponse("<script>window.location.href='/user/home/'</script>")

def cart(request):
    noofitemincart = addtocart.objects.all().count()
    if request.session.get('userid'):
        userid=request.session.get('userid')
        cursor=connection.cursor()
        cursor.execute("select c.*,p.* from user_addtocart c,user_products p where p.id=c.pid and userid='"+str(userid)+"'")
        cartdata=cursor.fetchall()
        pid=request.GET.get('pid')
        if request.GET.get('pid'):
            res=addtocart.objects.filter(id=pid,userid=userid)
            res.delete()
            return HttpResponse("<script>alert('Your product has been removed successfull');window.location.href='/user/cart/'</script>")
        #print(cartdata)
    return render(request,'user/cart.html',{"cart":cartdata,"noofitemincart":noofitemincart})