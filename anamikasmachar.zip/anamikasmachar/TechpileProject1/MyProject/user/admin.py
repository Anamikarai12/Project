from django.contrib import admin

# Register your models here.
from .models import *
admin.site.register(contact)

class categoryAdmin(admin.ModelAdmin):
    list_display = ('id','cname','cpic','cdate')
admin.site.register(category,categoryAdmin)


class newsAdmin(admin.ModelAdmin):
    list_display = ('id','city','headlines','subject','newsdes','newspic','ndate','ncategory')
admin.site.register(news,newsAdmin)

class videonewsAdmin(admin.ModelAdmin):
    list_display = ('id','vurls','vheadlines','vpara','vpic','vdate')
admin.site.register(videonews,videonewsAdmin)

class slidernewsAdmin(admin.ModelAdmin):
    list_display = ('id','sheadlines','spic','sdate')
admin.site.register(slidernews,slidernewsAdmin)

class notificationAdmin(admin.ModelAdmin):
    list_display = ('id','notheadlines','notdate')
admin.site.register(notification,notificationAdmin)

class cricketAdmin(admin.ModelAdmin):
    list_display = ('id','cricketpic','cridate')
admin.site.register(cricket,cricketAdmin)

class cityAdmin(admin.ModelAdmin):
    list_display = ('id','cityname','cdate')
admin.site.register(city,cityAdmin)