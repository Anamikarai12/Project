from django.urls import path,include
from . import views

urlpatterns=[
    path('',views.home),
    path('home/',views.home),
    path('about/',views.about),
    path('news/',views.viewnew),
    path('video/',views.video),
    path('contactus/',views.cont),
    path('viewmore/',views.viewmore),
    path('viewnews/',views.vnews),
path('login/',views.login),

]